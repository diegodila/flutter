class MunicipioModel {
  int id;
  String nome;
  String link;

  MunicipioModel({
    this.id,
    this.nome,
    this.link,
  });
}
