package com.example.appzyon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
